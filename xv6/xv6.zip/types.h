typedef unsigned int   uint;
typedef unsigned short ushort;
typedef unsigned char  uchar;
